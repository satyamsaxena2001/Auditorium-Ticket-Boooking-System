package movieBooking.common;

public class EventOver extends RuntimeException {
    public EventOver(String s) {
        super(s);
    }
}
