package movieBooking.common;

public @interface TODO {

    String value();

}
