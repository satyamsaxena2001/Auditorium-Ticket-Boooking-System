package movieBooking.common;

public @interface Multithreaded {

}
