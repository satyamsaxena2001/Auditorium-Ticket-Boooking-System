package movieBooking.common;

public @interface CHECK {

}
