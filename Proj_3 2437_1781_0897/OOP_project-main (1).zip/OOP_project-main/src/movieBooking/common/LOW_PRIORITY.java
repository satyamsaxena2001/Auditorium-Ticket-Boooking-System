package movieBooking.common;

public @interface LOW_PRIORITY {

}
