package movieBooking.common;

public @interface COMPLETE {

}
